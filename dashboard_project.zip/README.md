
# Sales & Financial Dashboard

This project presents an interactive dashboard built using Power BI to visualize and analyze sales and profit data.

## 📊 Dataset

The dataset contains fictional weekly sales data for multiple products across different regions during 2023.

## 📈 Dashboard Features

- **KPIs**: Total Revenue, Profit, Units Sold, Profit Margin
- **Charts**:
  - Time-series: Revenue and Profit over time
  - Bar Chart: Revenue by Region
  - Pie Chart: Revenue by Product
- **Slicers**: Region and Product filters
- **Cards**: Key metrics at a glance

## 🛠 Tools Used

- Power BI
- Python (for data generation)

## 📎 How to Use

1. Open `sales_data_dashboard.csv` in Power BI.
2. Use provided layout and screenshots to replicate the dashboard.
3. Customize visualizations as needed.

## 📷 Screenshots

Include your own screenshots in the `screenshots` folder after building the dashboard.
